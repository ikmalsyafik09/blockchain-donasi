import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <div className="nav">
      <div className="navContainer">
        <div className="navInner">
          <div className="navLeft">
            <div className="logo">R</div>
            <div className="titleWrap">
              <div className="titleMain">Ruang Peduli</div>
              <div className="titleSub">Donasi Digital untuk Masa Depan</div>
            </div>
          </div>

          <div className="navRight">
            <Link to="/">Beranda</Link>
            <Link to="/about">Tentang</Link>
            <Link to="/admin">Admin</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
