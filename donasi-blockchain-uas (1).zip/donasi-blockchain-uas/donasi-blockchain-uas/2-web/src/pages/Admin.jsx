import { useState } from "react";
import { ethers } from "ethers";
import { getContractWrite } from "../lib/ethers";

export default function Admin() {
  const [to, setTo] = useState("");
  const [eth, setEth] = useState("0.01");
  const [loading, setLoading] = useState(false);

  async function withdraw() {
    try {
      if (!window.ethereum) return alert("MetaMask belum terpasang");
      setLoading(true);

      const { contract } = await getContractWrite();

      const wei = ethers.parseEther(eth || "0");
      const tx = await contract.withdraw(to, wei);
      await tx.wait();

      alert("Withdraw berhasil");
    } catch (e) {
      alert(e?.shortMessage || e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="container section" style={{maxWidth:720}}>
      <h2 style={{marginTop:0}}>Admin</h2>
      <p style={{color:"#444", lineHeight:1.8}}>
        Menu ini hanya bisa dipakai oleh address yang melakukan deploy smart contract (owner).
      </p>

      <div style={{border:"1px solid #e7e7e7", borderRadius:12, padding:16, background:"#f6f7f6"}}>
        <div style={{fontSize:12, color:"#666"}}>Withdraw ke Address</div>
        <input
          style={{width:"100%", border:"1px solid #e7e7e7", borderRadius:10, padding:"10px 12px", marginTop:6}}
          value={to}
          onChange={(e)=>setTo(e.target.value)}
          placeholder="0x...."
        />

        <div style={{fontSize:12, color:"#666", marginTop:14}}>Jumlah (ETH)</div>
        <input
          style={{width:"100%", border:"1px solid #e7e7e7", borderRadius:10, padding:"10px 12px", marginTop:6}}
          value={eth}
          onChange={(e)=>setEth(e.target.value)}
          placeholder="0.01"
        />

        <button className="btn btnDonate" onClick={withdraw} disabled={loading} style={{marginTop:14}}>
          {loading ? "Memproses..." : "Tarik Dana"}
        </button>
      </div>
    </div>
  );
  
}
