import { useEffect, useMemo, useRef, useState } from "react";
import { ethers } from "ethers";
import heroImg from "../assets/hero.jpg";
import { getContractRead, getContractWrite } from "../lib/ethers";

export default function Home({ account, onConnect }) {
  const [info, setInfo] = useState({
    title: "",
    description: "",
    goalWei: 0n,
    totalWei: 0n,
    balanceWei: 0n
  });

  const [eth, setEth] = useState("0.01");
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [lastTx, setLastTx] = useState("");
  const [status, setStatus] = useState("");

  const explorerTx = import.meta.env.VITE_EXPLORER_TX;
  const explorerAddr = import.meta.env.VITE_EXPLORER_ADDR;
  const contractAddress = import.meta.env.VITE_CONTRACT_ADDRESS;

  // simpan instance contract read buat listener
  const readContractRef = useRef(null);

  async function load() {
    try {
      setStatus("Memuat data...");
      const { contract } = getContractRead();

      const [title, description, goalWei, totalRaisedWei, balanceWei] = await Promise.all([
        contract.title(),
        contract.description(),
        contract.goalWei(),
        contract.totalRaisedWei(),
        contract.contractBalance()
      ]);

      setInfo({
        title,
        description,
        goalWei,
        totalWei: totalRaisedWei,
        balanceWei
      });

      setStatus("");
    } catch (e) {
      setStatus("");
      console.error(e);
      alert(e?.message || String(e));
    }
  }

  // Load pertama + pasang listener event Donated biar auto update
  useEffect(() => {
    let contract;

    (async () => {
      try {
        const read = getContractRead();
        contract = read.contract;
        readContractRef.current = contract;

        // 1) load awal
        await load();

        // 2) kalau ada donasi dari siapapun, refresh angka
        contract.on("Donated", () => {
          load();
        });
      } catch (e) {
        console.error(e);
      }
    })();

    // cleanup listener saat pindah halaman / refresh
    return () => {
      try {
        if (contract) contract.removeAllListeners("Donated");
      } catch {}
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const goalEth = useMemo(() => Number(ethers.formatEther(info.goalWei || 0n)), [info.goalWei]);
  const totalEth = useMemo(() => Number(ethers.formatEther(info.totalWei || 0n)), [info.totalWei]);
  const pct = goalEth > 0 ? Math.min(100, (totalEth / goalEth) * 100) : 0;

  async function donateNow() {
    try {
      if (!window.ethereum) return alert("MetaMask belum terpasang");
      if (!account) {
        // minta connect dulu
        await onConnect();
        return;
      }

      setLoading(true);
      setStatus("Mengirim transaksi...");

      const { contract } = await getContractWrite();

      // Kirim transaksi donate
      const tx = await contract.donate(name || "Anon", message || "-", {
        value: ethers.parseEther(eth || "0")
      });

      setLastTx(tx.hash);
      setStatus("Menunggu konfirmasi blockchain...");

      // WAJIB: tunggu sampai masuk block
      await tx.wait();

      // WAJIB: refresh data setelah transaksi confirmed
      await load();

      setName("");
      setMessage("");
      setStatus("Donasi berhasil ✅");
      setTimeout(() => setStatus(""), 2000);
    } catch (e) {
      setStatus("");
      console.error(e);
      alert(e?.shortMessage || e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <div className="hero" id="donasi">
        <div className="heroImg">
          <img src={heroImg} alt="Ruang Peduli" />
        </div>

        <div className="heroPanel">
          <h1 className="heroTitle">{info.title || "Ruang Peduli"}</h1>
          <p className="heroSub">
            {info.description ||
              "Platform donasi digital berbasis blockchain untuk mendukung transparansi dan masa depan yang lebih baik."}
          </p>

          <div className="box">
            <div className="statsRow">
              <div>
                <div className="small">Dana Terkumpul</div>
                <b style={{ fontSize: 18 }}>{totalEth.toFixed(6)} ETH</b>
              </div>
              <div>
                <div className="small">Target Donasi</div>
                <b style={{ fontSize: 18 }}>{goalEth.toFixed(6)} ETH</b>
              </div>
              <div>
                <div className="small">Progres</div>
                <b style={{ fontSize: 18 }}>{pct.toFixed(1)}%</b>
              </div>
            </div>

            <div style={{ marginTop: 12 }}>
              <div className="progress">
                <div style={{ width: `${pct}%` }} />
              </div>

              <div className="small" style={{ marginTop: 10 }}>
                Saldo Smart Contract:{" "}
                <span className="mono">{ethers.formatEther(info.balanceWei || 0n)} ETH</span>
              </div>

              {status && (
                <div className="small" style={{ marginTop: 8 }}>
                  Status: <b>{status}</b>
                </div>
              )}
            </div>

            <div className="row" style={{ marginTop: 14 }}>
              {!account ? (
                <button className="btn" onClick={onConnect}>
                  Hubungkan Wallet
                </button>
              ) : (
                <span className="badge" title={account}>
                  {account.slice(0, 6)}…{account.slice(-4)}
                </span>
              )}

              <button className="btn btnDonate" onClick={donateNow} disabled={loading}>
                {loading ? "Memproses..." : "Donasi Sekarang"}
              </button>

              <button className="btn" onClick={load} disabled={loading}>
                Refresh
              </button>
            </div>

            <div className="label">Jumlah Donasi (ETH)</div>
            <input
              className="input"
              value={eth}
              onChange={(e) => setEth(e.target.value)}
              placeholder="0.01"
            />

            <div className="label">Nama (opsional)</div>
            <input
              className="input"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Misal: Andi"
            />

            <div className="label">Pesan (opsional)</div>
            <input
              className="input"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Semoga bermanfaat 🙏"
            />

            <div className="row" style={{ marginTop: 14 }}>
              <a
                className="btn"
                style={{
                  background: "rgba(255,255,255,.16)",
                  color: "#fff",
                  borderColor: "rgba(255,255,255,.35)"
                }}
                href={`${explorerAddr}${contractAddress}`}
                target="_blank"
                rel="noreferrer"
              >
                Lihat Kontrak
              </a>

              {lastTx && (
                <a
                  className="btn"
                  style={{
                    background: "rgba(255,255,255,.16)",
                    color: "#fff",
                    borderColor: "rgba(255,255,255,.35)"
                  }}
                  href={`${explorerTx}${lastTx}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  Lihat Transaksi Terakhir
                </a>
              )}
            </div>
          </div>

          <div className="small">
            *Angka akan otomatis berubah setelah transaksi terkonfirmasi (dan juga auto-update lewat event Donated).
          </div>
        </div>
      </div>

      <hr />

      <div className="section">
        <div className="container">
          <div style={{ textAlign: "center" }}>
            <h2 style={{ margin: "0 0 10px" }}>Donasi Digital untuk Masa Depan</h2>
            <div className="smallDark">Transparan, aman, dan tercatat langsung di blockchain.</div>
          </div>

          <div style={{ height: 16 }} />

          <div className="cards3">
            <div className="card">
              <div className="icon">👥</div>
              <b>Kepercayaan Donatur</b>
              <p>Donatur dapat memverifikasi transaksi melalui explorer kapan saja.</p>
            </div>
            <div className="card">
              <div className="icon">🔗</div>
              <b>Transparansi On-chain</b>
              <p>Donasi masuk ke smart contract dan tercatat publik.</p>
            </div>
            <div className="card">
              <div className="icon">✅</div>
              <b>Proses Sederhana</b>
              <p>Hubungkan wallet → isi jumlah → donasi → selesai.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="footer">
        <div className="container">
          <b>Ruang Peduli</b>
          <div className="small" style={{ marginTop: 8 }}>
            Platform Donasi Digital Berbasis Blockchain<br />
            Proyek UAS • Sepolia Testnet
          </div>
        </div>
      </div>
    </>
  );
}
